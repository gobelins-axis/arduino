# r89m Buttons Library v2.0.0
https://github.com/r89m/Button


Richard Miles April 2016

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)

## CC BY-SA
r89m Buttons Library by Richard Miles is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a letter to:
Creative Commons
444 Castro Street, Suite 900
Mountain View, CA 94041  
